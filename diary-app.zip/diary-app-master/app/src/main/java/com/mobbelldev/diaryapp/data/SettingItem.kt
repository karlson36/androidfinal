package com.mobbelldev.diaryapp.data

data class SettingItem(
    val iconResId: Int,
    var title: String,
    val hasSwitch: Boolean,
)
